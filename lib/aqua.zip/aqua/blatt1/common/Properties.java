package aqua.blatt1.common;

public class Properties {
	public final static String HOST = "localhost";
	public final static int PORT = 4711;
	public final static String BROKER_NAME = "AquaBroker";
}
